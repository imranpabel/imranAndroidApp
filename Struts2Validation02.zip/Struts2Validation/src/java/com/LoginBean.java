/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.validator.annotations.RegexFieldValidator;

/**
 *
 * @author Teacher
 */
public class LoginBean extends ActionSupport{
    private String name;
    private String password;
    private String reg;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

//    @Override
//    public void validate() {
//       if(name.length()<1||(password.length()<1)){
//           addActionError("All is Required");
//       }
//      
//    }

    @Override
    public String execute() throws Exception {
       return SUCCESS;
    }
//@RegexFieldValidator(
//    regex = "[0-9]",
//    message = "Please enter a valid phone number"
//)
public String getReg() {
        return reg;
    }

    public void setReg(String reg) {
        this.reg = reg;
    }
    
    
}
